// Package licensesdk is a binary-only package, it provides license related functions with LicenseHandler
// and quota related functions with QuotaManager,
// a LicenseHandler instance must be created before creating a QuotaManager instance

//go:binary-only-package

package licensesdk

// LicenseHandler provides license properties check
/*
type LicenseHandler struct {}
*/

// NewLicenseHandler is LicenseHandler factory, unique way to create LicenseHandler
/*
func NewLicenseHandler(lic []byte, product string, udid string) (*LicenseHandler, error) {}
*/

// CheckExpiration checks whether a license is still in expiration date
/*
func (lh *LicenseHandler) CheckExpiration() bool {}
*/

// CheckCapability checks whether a capability in license capabilities list
/*

 */
// func (lh *LicenseHandler) CheckCapability(capability string) (bool, error) {}

// CheckPlatform checks whether a platform in license platforms list
/*
func (lh *LicenseHandler) CheckPlatform(plat string) bool {}
*/

// CheckVersion checks whether a version in license versions list
/*
func (lh *LicenseHandler) CheckVersion(version string) bool {}
*/

// CheckActivationType checks whether a activation type matches the license
/*
func (lh *LicenseHandler) CheckActivationType(actType string) bool {}
*/

// GetLimit returns ext limits from license
/*
func (lh *LicenseHandler) GetLimit(limitName string) interface{} {}
*/

// CounterCheckIn checks in a capability, decrease the capability counter by 1
/*
func (lh *LicenseHandler) CounterCheckIn(prodName, capabilityName string) error {}
*/

// CounterCheckOut checks out a capability, increase the capability counter by 1
/*
func (lh *LicenseHandler) CounterCheckOut(prodName, capabilityName string) error {}
*/
