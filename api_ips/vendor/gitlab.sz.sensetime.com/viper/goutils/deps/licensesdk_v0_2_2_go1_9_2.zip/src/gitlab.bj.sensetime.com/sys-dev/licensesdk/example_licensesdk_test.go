// Package licensesdk_test is sample of LicenseHandler and QuotaManager
// a LicenseHandler instance must be created before creating a QuotaManager instance
package licensesdk_test

import (
	"io/ioutil"
	"log"

	lh "gitlab.bj.sensetime.com/sys-dev/licensesdk"
)

const (
	licDir           = "sample/validLic.lic"
	slaveLicDir      = "sample/slave1.lic"
	successProd      = "TestForAllan"
	successQuotaProd = "LicenseCA"
	successUUID      = "uuid_for_test"
	successActType   = "verify_v1"
	successCapa      = "face"    //["face", "money"]
	successPlat      = "ios"     //["ios", "osx", "android"]
	successVersion   = "1.0.0"   //[1.0.0, 1.2.0]
	successCounter   = "threads" //{"threads": 7, "devices": 9}
	successExtLimits = "users"   // ["users", "capability", "_hardware_auth", "_hardware_auth_key"]
)

func Example() {
	srcLic, err := ioutil.ReadFile(licDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	licHandler, err := lh.NewLicenseHandler(srcLic, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}

	//check uuid, return bool
	if !licHandler.CheckUdid(successUUID) {
		log.Fatalf("uuid : %s check failed!", successUUID)
	} else {
		log.Printf("uuid : %s check success!", successUUID)
	}

	//check expiration, return bool
	if !licHandler.CheckExpiration() {
		log.Fatalf("license not in expiration!")
	} else {
		log.Printf("license in expiration!")
	}

	//check platform, return bool
	if !licHandler.CheckPlatform(successPlat) {
		log.Fatalf("platform : %s check failed!", successPlat)
	} else {
		log.Printf("platform : %s check success!", successPlat)
	}

	//check version, return bool
	if !licHandler.CheckVersion(successVersion) {
		log.Fatalf("version : %s check failed!", successVersion)
	} else {
		log.Printf("version : %s check success!", successVersion)
	}

	//check capability, return bool
	if val, err := licHandler.CheckCapability(successCapa); err != nil {
		log.Fatalf("capability : %s check failed!", successCapa)
	} else {
		log.Printf("capability : %s check success and value is %v", successCapa, val)
	}

	// check activation type, return bool
	if !licHandler.CheckActivationType(successActType) {
		log.Fatalf("Activation type : %s failed!", successActType)
	} else {
		log.Printf("Activation type : %s success!", successActType)
	}

	//counter check out, return nil or error
	if err := licHandler.CounterCheckOut(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check out failed!", successCounter, successProd)
	} else {
		log.Printf("counter : %s in product : %s check out success!", successCounter, successProd)
	}

	//counter check in, return nil or error
	if err := licHandler.CounterCheckIn(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check in failed!", successCounter, successProd)
	} else {
		log.Printf("counter : %s in product : %s check in success!", successCounter, successProd)
	}

	//get limit, basic or extended limits
	if val := licHandler.GetLimit(successExtLimits); val == nil {
		log.Fatalf("limit : %s get failed!", successExtLimits)
	} else {
		log.Printf("limit : %s's value is %v", successExtLimits, val)
	}

	quoLic, err := ioutil.ReadFile(slaveLicDir)
	if err != nil {
		log.Fatalf("Read license failed")
	}

	// construct a slave license handler, only "ca_private" activation type can use QuotaManager
	lhQuota, _ := lh.NewLicenseHandler(quoLic, successQuotaProd, successUUID)
	qm, err := lh.NewQuotaManager(successUUID, lhQuota)
	if err != nil {
		log.Fatalf("failed : %v", err)
	}
	quotas := make(map[string]int32, 4)
	quotas["test1"] = 1
	quotas["test2"] = 1

	// user should call UpdateRequestQuota(quotas) first to finish initialize before Run().
	// UpdateRequestQuota() returns the last request version, this is a asynchronous and non-block function,
	// it triggers sdk to send a message to ca and user should read results asynchronously from channel which Status() returns.
	// if user wants to set quotas to a new version, call UpdateRequestQuota(quotas) and read results from channel which Status() returns.
	// if needed user can compare last request version(return value of UpdateRequestQuota) and current version(results from Status() channel)
	// when a crash occurs or user wants to exit, call Close() to finish
	lastReqVer := qm.UpdateRequestQuota(quotas)
	log.Printf("Last request version is %d\n", lastReqVer)

	if err := qm.Run(); err != nil {
		log.Fatalf("Run failed : %v", err)
	}

	// Status return a channel
	// user should process errors whose code starts with "0",
	// errors that code starts with "1" is sdk internal error, just for debug
	for status := range qm.Status() {
		switch status.Err.Code {
		case "000000": // success
			log.Println(status.Err.Message)
			if lastReqVer != status.Version {
				// do something you want
				log.Println("do something you want")
			} else {
				// do something you want
				log.Println("do something you want")
			}
		case "000001": // ca encounters fatal error
			log.Println("fatal error from ca")
		case "000002": // quota is out of date
			log.Println("quota out of date")
		case "000003": // apply quota from ca failed
			log.Println("apply quota from ca failed")
		case "000004": // unauthorized, token error
			log.Println("unauthorized")
		default:
			log.Println(status.Err.Code)
			log.Println(status.Err.Message)
			log.Println("this is sdk internal error, no need to process, just for debug")
		}
		log.Printf("Quota status from ca Version is %d, and limits is %v\n", status.Version, status.Limits)
	}

	//call when finish
	if err := qm.Close(); err != nil {
		log.Fatalf("Close failed : %v", err)
	}
}
