// Package licensesdk is a binary-only package, it provides license related functions with LicenseHandler
// and quota related functions with QuotaManager,
// a LicenseHandler instance must be created before creating a QuotaManager instance

//go:binary-only-package

package licensesdk

// QuotaManager provides quota set and get functions
/*
type QuotaManager struct {}
*/

// QuotaLimit carries current and free quota
/*
type QuotaLimit struct {
	Current int32
	Free    int32
}
*/

// Error defines errors from sdk to users
/*
type Error struct {
	Code    string
	Message string
}
*/

// QuotaManagerError describes error code and message, user should process errors whose code starts with "0",
// errors that code starts with "1" is sdk internal error
/*
var QuotaManagerError = map[string]Error{
	"Success":         {Code: "000000", Message: "success"},
	"CAFatalErr":      {Code: "000001", Message: "fatal error from ca"},
	"QuotaExpiredErr": {Code: "000002", Message: "quota out of date"},
	"QuotaApplyErr":   {Code: "000003", Message: "apply quota from ca failed"},
	"ConstructMsgErr": {Code: "100001", Message: "construct message failed"},
	"ParseMsgErr":     {Code: "100002", Message: "parse message error"},
}
*/

// QuotaStatus carries current quota limits, version and error status
/*
type QuotaStatus struct {
	Err     Error
	Version int32
	Limits  map[string]QuotaLimit
}
*/

// NewQuotaManagerWithCA creates quota manager with self-define certs and urls
// with returned QuotaManager, user can update and get quota status
/*
func NewQuotaManagerWithCA(clientID string, licHandler *LicenseHandler, masterCACert, masterClientCert,
    slaveCACert, slaveClientCert, masterCAURL, slaveCAURL []byte) (*QuotaManager, error) {}
*/

// NewQuotaManager creates quota manager with default ca certs and urls
// with returned QuotaManager, user can update and get quota status
/*
func NewQuotaManager(clientID string, licHandler *LicenseHandler) (*QuotaManager, error) {}
*/

// UpdateRequestQuota set requested quota, not block, trigger a immediate heartbeat to ca
/*
func (qm *QuotaManager) UpdateRequestQuota(quota map[string]int32) int32 {}
*/

// Run starts quota manager loop, and two mechanism to communicate with ca
// first way is send a heartbeat to ca on a ticker with 5 seconds interval
// second way is send a heartbeat immediately when receives a signal from channel
/*
func (qm *QuotaManager) Run() error {}
*/

// Close close ticker, channels of QuotaManager
/*
func (qm *QuotaManager) Close() error {}
*/

// Status returns quota status channel, user should read data from this channel to keep channel data fresh
/*
func (qm *QuotaManager) Status() <-chan QuotaStatus {}
*/
