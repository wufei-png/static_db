// Package licensesdk is a binary-only package, it provides license related functions with LicenseHandler
// and quota related functions with QuotaManager,
// a LicenseHandler instance must be created before creating a QuotaManager instance

//go:binary-only-package

package licensesdk

// LicenseHandler provides license properties check
/*
type LicenseHandler struct {}
*/

// NewLicenseHandler is LicenseHandler factory, unique way to create LicenseHandler
// input param lic, license content read from license file(for example, client.lic)
// input param product, product name, set when signing a license, should match with value in license file
// input param uuid, unique id, can be set when signing a license. if not set, input a null str here
/*
func NewLicenseHandler(lic []byte, product string, uuid string) (*LicenseHandler, error) {}
*/

// CheckUdid checks whether a udid match the license, udid is an optional field
// input param udid, if set in license, check if input udid matches value in license
/*
func (lh *LicenseHandler) CheckUdid(udid string) bool
*/

// CheckExpiration checks whether a license is still in expiration date, expiration is a mandatory field
/*
func (lh *LicenseHandler) CheckExpiration() bool {}
*/

// CheckCapability checks whether a capability in license capabilities list, capability is an optional field
// capability value is boolean type, return value(false, nil), capability exists but value is false
// return value(true, nil), capability exists and value is true
// return value(false, error), capability noty exists
// input param capability, is capability name user wants to check
/*
func (lh *LicenseHandler) CheckCapability(capability string) (bool, error) {}
*/

// CheckPlatform checks whether a input platform name in license platforms list, paltform is an optional field
// if no platform setting in license, any platform value is ok
// input param plat, is platform name to check
/*
func (lh *LicenseHandler) CheckPlatform(plat string) bool {}
*/

// CheckVersion checks whether a sdk version in license versions list, version is an optional field
// if no versions setting in license, any version value is ok
// input param version, is sdk version to check
/*
func (lh *LicenseHandler) CheckVersion(version string) bool {}
*/

// CheckActivationType checks whether a activation type matches the license, activation type is a mandatory field
// input param actType, is activation type to check
/*
func (lh *LicenseHandler) CheckActivationType(actType string) bool {}
*/

// GetLimit returns ext limits from license, limit is an optional field
// input param limitName, is limit name which is the key of limit value user wants to get
// return value is interface type, user should judge the real type(int or string)
/*
func (lh *LicenseHandler) GetLimit(limitName string) interface{} {}
*/

// CounterCheckIn checks in a capability, decrease the capability counter by 1, counter is an optional field
// input param prodName, is product name that must match the value in license
// input param capabilityName, is a capability name to checkin in counter(a field in license)
/*
func (lh *LicenseHandler) CounterCheckIn(prodName, capabilityName string) error {}
*/

// CounterCheckOut checks out a capability, increase the capability counter by 1, counter is an optional field
// input param prodName, is product name that must match the value in license
// input param capabilityName, is a capability name to checkout in counter(a field in license)
/*
func (lh *LicenseHandler) CounterCheckOut(prodName, capabilityName string) error {}
*/
