// Package licensesdk_test is sample of LicenseHandler and QuotaManager
// a LicenseHandler instance must be created before creating a QuotaManager instance
package licensesdk_test

import (
	"io/ioutil"
	"log"

	lh "gitlab.bj.sensetime.com/sys-dev/licensesdk"
)

const (
	clientLicDir     = "sample/client.lic"
	successProd      = "LicenseCA"
	successUUID      = "uuid_for_test"
	successActType   = "ca_private"
	successCapa      = "face"    //["face", "money"]
	successPlat      = "osx"     //["osx", "linux", "ios", "android"]
	successVersion   = "1.0.0"   //[1.0.0, 1.5.0]
	successCounter   = "threads" //{"threads": 10}
	successExtLimits = "users"   // ["users", "capability"]
)

func Example() {
	// ************************************sample for license property check start***************************************
	srcLic, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param srcLic, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandler, err := lh.NewLicenseHandler(srcLic, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}

	// check uuid, return bool, udid is an optional field
	// if no udid setting in license, no need to check, call this when needed
	if !licHandler.CheckUdid(successUUID) {
		log.Fatalf("uuid : %s check failed!", successUUID)
	} else {
		log.Printf("uuid : %s check success!", successUUID)
	}

	// check expiration, return bool, expiration is a mandatory field
	// call this when using a LicenseHandler instance is strongly advised
	if !licHandler.CheckExpiration() {
		log.Fatalf("license not in expiration!")
	} else {
		log.Printf("license in expiration!")
	}

	// check platform, return bool, platform is an optional field
	// if this value not set in a license, any platform is ok
	// call this when needed
	if !licHandler.CheckPlatform(successPlat) {
		log.Fatalf("platform : %s check failed!", successPlat)
	} else {
		log.Printf("platform : %s check success!", successPlat)
	}

	// check version, return bool, version is an optional field
	// if this value not set in a license, any version is ok
	// call this when needed
	if !licHandler.CheckVersion(successVersion) {
		log.Fatalf("version : %s check failed!", successVersion)
	} else {
		log.Printf("version : %s check success!", successVersion)
	}

	// check capability, return bool, capability is an optional field
	// it's a self-defined field when signing a license, capability value is boolean type
	// return value(false, nil), capability exists but value is false
	// return value(true, nil), capability exists and value is true
	// return value(false, error), capability noty exists
	// input param successCapa, is capability name user wants to check
	// call this when needed
	if val, err := licHandler.CheckCapability(successCapa); err != nil {
		log.Fatalf("capability : %s check failed!", successCapa)
	} else {
		log.Printf("capability : %s check success and value is %v", successCapa, val)
	}

	// check activation type, return bool, activation type is a mandatory field
	// different license with different activation type is used for different purpose, it must be matched
	// call this when using a LicenseHandler instance is strongly advised
	if !licHandler.CheckActivationType(successActType) {
		log.Fatalf("Activation type : %s failed!", successActType)
	} else {
		log.Printf("Activation type : %s success!", successActType)
	}

	// counter check out, return nil or error, counter is an optional field
	// it's a self-defined field when signing a license
	// call this when needed
	if err := licHandler.CounterCheckOut(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check out failed, and err is %v", successCounter, successProd, err)
	} else {
		log.Printf("counter : %s in product : %s check out success!", successCounter, successProd)
	}

	//counter check in, return nil or error, counter is an optional field
	// it's a self-defined field when signing a license
	// call this when needed
	if err := licHandler.CounterCheckIn(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check in failed!", successCounter, successProd)
	} else {
		log.Printf("counter : %s in product : %s check in success!", successCounter, successProd)
	}

	// get limit, basic or extended limits
	// call this when needed
	if val := licHandler.GetLimit(successExtLimits); val == nil {
		log.Fatalf("limit : %s get failed!", successExtLimits)
	} else {
		switch val.(type) {
		case int:
			log.Printf("int value is : %d\n", val.(int))
		case string:
			log.Printf("int value is : %s\n", val.(string))
		}
		log.Printf("limit : %s's value is %v", successExtLimits, val)
	}
	// ************************************sample for license property check end***************************************

	// *******************************sample for getting limit and check capability start**********************************
	licContent, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param licContent, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandler2, err := lh.NewLicenseHandler(licContent, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}
	// input param limitName, is limit name which is the key of limit value user wants to get
	// return value is interface type, user should judge the real type(int or string)
	if val := licHandler2.GetLimit(successExtLimits); val == nil {
		log.Fatalf("limit : %s get failed!", successExtLimits)
	} else {
		switch val.(type) {
		case int:
			log.Printf("int value is : %d\n", val.(int))
		case string:
			log.Printf("int value is : %s\n", val.(string))
		}
		log.Printf("limit : %s's value is %v", successExtLimits, val)
	}

	// check capability, return bool, capability is an optional field
	// it's a self-defined field when signing a license, capability value is boolean type
	// return value(false, nil), capability exists but value is false
	// return value(true, nil), capability exists and value is true
	// return value(false, error), capability noty exists
	// input param successCapa, is capability name user wants to check
	// call this when needed
	if val, err := licHandler2.CheckCapability(successCapa); err != nil {
		log.Fatalf("capability : %s check failed!", successCapa)
	} else {
		log.Printf("capability : %s check success and value is %v", successCapa, val)
	}
	// *******************************sample for getting limit and check capability end************************************

	// ***************************************sample for getting quotas start**********************************************
	licContentQ, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param licContent, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandlerQ, err := lh.NewLicenseHandler(licContentQ, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}
	// construct a QuotaManger instance, functions below is used for this sdk to get/set quotas and consts from/to ca
	// just create a LicenseHandler instance before this, the two parts functions can be used separately
	// only license with activation type "ca-private" can be used to create a QuotaManager instance
	qm, err := lh.NewQuotaManager(successUUID, licHandlerQ)
	if err != nil {
		log.Fatalf("failed : %v", err)
	}
	quotas := make(map[string]int32, 4)
	quotas["test1"] = 1
	quotas["test2"] = 1
	consts := []string{"sense", "time"}

	// user should call UpdateRequestQuota(quotas) first to finish initialize before Run().
	// UpdateRequestQuota() returns the last request version, this is a asynchronous and non-block function,
	// it triggers sdk to send a message to ca and user should read results asynchronously from channel which Status() returns.
	// if user wants to set quotas to a new version, call UpdateRequestQuota(quotas) and read results from channel which Status() returns.
	// if needed user can compare last request version(return value of UpdateRequestQuota) and current version(results from Status() channel)
	// when a crash occurs or user wants to exit, call Close() to finish
	lastReqVer := qm.UpdateRequestQuota(quotas, consts)
	log.Printf("Last request version is %d\n", lastReqVer)

	if err := qm.Run(); err != nil {
		log.Fatalf("Run failed : %v", err)
	}

	// Status return a channel
	// user should process errors whose code starts with "0",
	// errors that code starts with "1" is sdk internal error, just for debug
	for status := range qm.Status() {
		switch status.Err.Code {
		case "000000": // success
			log.Println(status.Err.Message)
			if lastReqVer != status.Version {
				// do something you want
				log.Println("do something you want")
			} else {
				// do something you want
				log.Println("do something you want")
			}
			for _, v := range status.Consts {
				switch v.(type) {
				case int32:
					log.Printf("int32 value is %d\n", v)
				case string:
					log.Printf("string value is %s\n", v)
				default:
					log.Println("value type is invalid")
				}
			}
			log.Printf("Version is %d, and limits is %v, consts is %v\n", status.Version, status.Limits, status.Consts)
		case "000001": // ca encounters fatal error
			log.Println("fatal error from ca")
		case "000002": // quota is out of date
			log.Println("quota out of date")
		case "000003": // apply quota from ca failed
			log.Println("apply quota from ca failed")
		case "000004": // unauthorized, token error
			log.Println("unauthorized")
		default:
			log.Println(status.Err.Code)
			log.Println(status.Err.Message)
			log.Println("this is sdk internal error, no need to process, just for debug")
		}
	}

	//call when finish
	if err := qm.Close(); err != nil {
		log.Fatalf("Close failed : %v", err)
	}
	// ***************************************sample for getting quotas end**********************************************
}

func ExampleNewLicenseHandler() {
	// ************************************sample for license property check start***************************************
	srcLic, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param srcLic, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandler, err := lh.NewLicenseHandler(srcLic, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}

	// check uuid, return bool, udid is an optional field
	// if no udid setting in license, no need to check, call this when needed
	if !licHandler.CheckUdid(successUUID) {
		log.Fatalf("uuid : %s check failed!", successUUID)
	} else {
		log.Printf("uuid : %s check success!", successUUID)
	}
	// check expiration, return bool, expiration is a mandatory field
	// call this when using a LicenseHandler instance is strongly advised
	if !licHandler.CheckExpiration() {
		log.Fatalf("license not in expiration!")
	} else {
		log.Printf("license in expiration!")
	}

	// check platform, return bool, platform is an optional field
	// if this value not set in a license, any platform is ok
	// call this when needed
	if !licHandler.CheckPlatform(successPlat) {
		log.Fatalf("platform : %s check failed!", successPlat)
	} else {
		log.Printf("platform : %s check success!", successPlat)
	}

	// check version, return bool, version is an optional field
	// if this value not set in a license, any version is ok
	// call this when needed
	if !licHandler.CheckVersion(successVersion) {
		log.Fatalf("version : %s check failed!", successVersion)
	} else {
		log.Printf("version : %s check success!", successVersion)
	}

	// check capability, return bool, capability is an optional field
	// it's a self-defined field when signing a license, capability value is boolean type
	// return value(false, nil), capability exists but value is false
	// return value(true, nil), capability exists and value is true
	// return value(false, error), capability noty exists
	// input param successCapa, is capability name user wants to check
	// call this when needed
	if val, err := licHandler.CheckCapability(successCapa); err != nil {
		log.Fatalf("capability : %s check failed!", successCapa)
	} else {
		log.Printf("capability : %s check success and value is %v", successCapa, val)
	}

	// check activation type, return bool, activation type is a mandatory field
	// different license with different activation type is used for different purpose, it must be matched
	// call this when using a LicenseHandler instance is strongly advised
	if !licHandler.CheckActivationType(successActType) {
		log.Fatalf("Activation type : %s failed!", successActType)
	} else {
		log.Printf("Activation type : %s success!", successActType)
	}

	// counter check out, return nil or error, counter is an optional field
	// it's a self-defined field when signing a license
	// call this when needed
	if err := licHandler.CounterCheckOut(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check out failed, and err is %v", successCounter, successProd, err)
	} else {
		log.Printf("counter : %s in product : %s check out success!", successCounter, successProd)
	}

	//counter check in, return nil or error, counter is an optional field
	// it's a self-defined field when signing a license
	// call this when needed
	if err := licHandler.CounterCheckIn(successProd, successCounter); err != nil {
		log.Fatalf("counter : %s in product : %s check in failed!", successCounter, successProd)
	} else {
		log.Printf("counter : %s in product : %s check in success!", successCounter, successProd)
	}

	// get limit, basic or extended limits
	// call this when needed
	if val := licHandler.GetLimit(successExtLimits); val == nil {
		log.Fatalf("limit : %s get failed!", successExtLimits)
	} else {
		switch val.(type) {
		case int:
			log.Printf("int value is : %d\n", val.(int))
		case string:
			log.Printf("int value is : %s\n", val.(string))
		}
		log.Printf("limit : %s's value is %v", successExtLimits, val)
	}
	// ************************************sample for license property check end***************************************

	// *******************************sample for getting limit and check capability start**********************************
	licContent, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param licContent, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandler2, err := lh.NewLicenseHandler(licContent, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}
	// input param limitName, is limit name which is the key of limit value user wants to get
	// return value is interface type, user should judge the real type(int or string)
	if val := licHandler2.GetLimit(successExtLimits); val == nil {
		log.Fatalf("limit : %s get failed!", successExtLimits)
	} else {
		switch val.(type) {
		case int:
			log.Printf("int value is : %d\n", val.(int))
		case string:
			log.Printf("int value is : %s\n", val.(string))
		}
		log.Printf("limit : %s's value is %v", successExtLimits, val)
	}

	// check capability, return bool, capability is an optional field
	// it's a self-defined field when signing a license, capability value is boolean type
	// return value(false, nil), capability exists but value is false
	// return value(true, nil), capability exists and value is true
	// return value(false, error), capability noty exists
	// input param successCapa, is capability name user wants to check
	// call this when needed
	if val, err := licHandler2.CheckCapability(successCapa); err != nil {
		log.Fatalf("capability : %s check failed!", successCapa)
	} else {
		log.Printf("capability : %s check success and value is %v", successCapa, val)
	}
	// *******************************sample for getting limit and check capability end************************************

}

func ExampleNewQuotaManager() {
	licContentQ, err := ioutil.ReadFile(clientLicDir)
	if err != nil {
		log.Fatal("Read license failed")
	}

	// construct a license handler
	// input param licContent, license content read from license file(for example, client.lic)
	// input param successProd, product name, set when signing a license, should match with value in license file
	// input param successUUID, unique device id, can be set when signing a license. if not set, input a null str here
	licHandlerQ, err := lh.NewLicenseHandler(licContentQ, successProd, successUUID)
	if err != nil {
		log.Fatalf("Product name : %s, uuid : %s create license handler failed!", successProd, successUUID)
	} else {
		log.Printf("Product name : %s, uuid : %s create license check handler!", successProd, successUUID)
	}
	// construct a QuotaManger instance, functions below is used for this sdk to get/set quotas and consts from/to ca
	// just create a LicenseHandler instance before this, the two parts functions can be used separately
	// only license with activation type "ca-private" can be used to create a QuotaManager instance
	qm, err := lh.NewQuotaManager(successUUID, licHandlerQ)
	if err != nil {
		log.Fatalf("failed : %v", err)
	}
	quotas := make(map[string]int32, 4)
	quotas["test1"] = 1
	quotas["test2"] = 1
	consts := []string{"sense", "time"}

	// user should call UpdateRequestQuota(quotas) first to finish initialize before Run().
	// UpdateRequestQuota() returns the last request version, this is a asynchronous and non-block function,
	// it triggers sdk to send a message to ca and user should read results asynchronously from channel which Status() returns.
	// if user wants to set quotas to a new version, call UpdateRequestQuota(quotas) and read results from channel which Status() returns.
	// if needed user can compare last request version(return value of UpdateRequestQuota) and current version(results from Status() channel)
	// when a crash occurs or user wants to exit, call Close() to finish
	lastReqVer := qm.UpdateRequestQuota(quotas, consts)
	log.Printf("Last request version is %d\n", lastReqVer)

	if err := qm.Run(); err != nil {
		log.Fatalf("Run failed : %v", err)
	}

	// Status return a channel
	// user should process errors whose code starts with "0",
	// errors that code starts with "1" is sdk internal error, just for debug
	for status := range qm.Status() {
		switch status.Err.Code {
		case "000000": // success
			log.Println(status.Err.Message)
			if lastReqVer != status.Version {
				// do something you want
				log.Println("do something you want")
			} else {
				// do something you want
				log.Println("do something you want")
			}
			for _, v := range status.Consts {
				switch v.(type) {
				case int32:
					log.Printf("int32 value is %d\n", v)
				case string:
					log.Printf("string value is %s\n", v)
				default:
					log.Println("value type is invalid")
				}
			}
			log.Printf("Version is %d, and limits is %v, consts is %v\n", status.Version, status.Limits, status.Consts)
		case "000001": // ca encounters fatal error
			log.Println("fatal error from ca")
		case "000002": // quota is out of date
			log.Println("quota out of date")
		case "000003": // apply quota from ca failed
			log.Println("apply quota from ca failed")
		case "000004": // unauthorized, token error
			log.Println("unauthorized")
		default:
			log.Println(status.Err.Code)
			log.Println(status.Err.Message)
			log.Println("this is sdk internal error, no need to process, just for debug")
		}
	}

	//call when finish
	if err := qm.Close(); err != nil {
		log.Fatalf("Close failed : %v", err)
	}
}
