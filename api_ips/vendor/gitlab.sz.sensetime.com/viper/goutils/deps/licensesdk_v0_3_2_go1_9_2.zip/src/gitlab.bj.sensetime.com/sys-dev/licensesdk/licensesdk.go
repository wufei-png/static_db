// Package licensesdk is a binary-only package, it provides license related functions with LicenseHandler
// and quota related functions with QuotaManager,
// a LicenseHandler instance must be created before creating a QuotaManager instance

//go:binary-only-package

package licensesdk

// QuotaManager provides quota set and get functions
/*
type QuotaManager struct {}
*/

// QuotaLimit carries current and free quota
/*
type QuotaLimit struct {
	Current int32
	Free    int32
}
*/

// Error defines errors from sdk to users
/*
type Error struct {
	Code    string
	Message string
}
*/

// QuotaManagerError describes error code and message, user should process errors whose code starts with "0",
// errors that code starts with "1" is sdk internal error
/*
var QuotaManagerError = map[string]Error{
	"Success":         {Code: "000000", Message: "success"},
	"CAFatalErr":      {Code: "000001", Message: "fatal error from ca"},
	"QuotaExpiredErr": {Code: "000002", Message: "quota out of date"},
	"QuotaApplyErr":   {Code: "000003", Message: "apply quota from ca failed"},
	"AuthErr":         {Code: "000004", Message: "unauthorized"},
	"ConstructMsgErr": {Code: "100001", Message: "construct message failed"},
	"ParseMsgErr":     {Code: "100002", Message: "parse message error"},
	"WrongCloseErr":   {Code: "100003", Message: "quota manager already closed"},
}
*/

// QuotaStatus carries current quota limits, const limits, version and error status
/*
type QuotaStatus struct {
	Err     Error
	Version int32
	Limits  map[string]QuotaLimit
	Consts  map[string]interface{} // value type will be int32 or string
}
*/
// ConstStatus define struct of const status from ca
/*
type ConstStatus struct {
	StrConst string `json:"str_const"`
	IntConst int32  `json:"int_const"`
	IsStr    bool   `json:"is_str"`
}
*/

// NewQuotaManagerWithCA creates quota manager with self-define certs and urls
// with returned QuotaManager, user can update and get quota status
// input param UUID, a unique id, if set in license, the value should same with value in license, if not set, user input a unique id instead
// input param licHandler, create by NewLicenseHandler()
// input param masterCACert, master CA server cert
// input param masterClientCert, master client cert, if ca is master, client cert must be master too
// input param slaveCACert, slave CA server cert
// input param slaveClientCert, slave client cert, if ca is slave, client cert must be slave too
// input param masterCAURL, master CA server's address
// input param slaveCAURL, slave CA server's address
// input param masterCACert, master CA server cert
/*
func NewQuotaManagerWithCA(UUID string, licHandler *LicenseHandler, masterCACert, masterClientCert,
    slaveCACert, slaveClientCert, masterCAURL, slaveCAURL []byte) (*QuotaManager, error) {}
*/

// NewQuotaManager creates quota manager with default ca certs and urls
// with returned QuotaManager, user can update and get quota status
// input param UUID, a unique id, if set in license, the value should same with value in license, if not set, user input a unique id instead
// input param licHandler, create by NewLicenseHandler()
/*
func NewQuotaManager(UUID string, licHandler *LicenseHandler) (*QuotaManager, error) {}
*/

// UpdateRequestQuota set requested quota and limits, not block, trigger a immediate heartbeat to ca
// input param quota, is quota value user wants to get from ca, quota is set in ca's license
// input param consts, is a list of keys related to values user wants to get from ca, consts is set in ca's license
/*
func (qm *QuotaManager) UpdateRequestQuota(quota map[string]int32) int32 {}
*/

// Run starts quota manager loop, and two mechanism to communicate with ca
// first way is send a heartbeat to ca on a ticker with 5 seconds interval
// second way is send a heartbeat immediately when receives a signal from channel
/*
func (qm *QuotaManager) Run() error {}
*/

// Close close ticker, channels of QuotaManager
/*
func (qm *QuotaManager) Close() error {}
*/

// Status returns quota status channel, user should read data from this channel to keep channel data fresh
/*
func (qm *QuotaManager) Status() <-chan QuotaStatus {}
*/
